function validation() {

            var userName = document.getElementById('user').value;

            var password = document.getElementById('pass').value;

            var cpwd = document.getElementById('cnfpass').value;

            var contact = document.getElementById('num').value;

            var email = document.getElementById('mail').value;

           

            if (userName.length <8) {

                document.getElementById('username').innerHTML = "* Please fill valid Username field";

                return false;

            }

           

            if (password.length<8) {

                document.getElementById('password').innerHTML = "* Please fill valid Password field";

                return false;

            }

 

            if (cpwd.length<8 || cpwd.length>15) {

                document.getElementById('CnPwd').innerHTML = "* Please fill valid Confirm Password ";

                return false;

            }

 

            if (contact.length<10) {

                document.getElementById('contactNO').innerHTML = "* Please fill valid contact field";

                return false;

            }

 

            if (email == "") {

                document.getElementById('email').innerHTML = "* Please fill Email field";

                return false;

            }

 

        }

   