var milSec=0;
var Sec=0;
var min=0;
var MSec = document.getElementById('sec');
var Seconds = document.getElementById('min');
var Minutes = document.getElementById('hr');
var StartT = document.getElementById('start');
var PauseT = document.getElementById('pause');
var StopT = document.getElementById('stop');
var interval;
StartT.onclick = function(){
    clearInterval(interval);
    interval= setInterval(startTimer,10);
}

PauseT.onclick = function(){
    clearInterval(interval);
}

StopT.onclick = function(){
    clearInterval(interval);
    milSec="00";
    Sec="00";
    min="00";
    MSec.innerHTML =  milSec;
    Seconds.innerHTML = Sec;
    Minutes.innerHTML = min;
}

function startTimer(){
    milSec++;
    if(milSec<=9){
        MSec.innerHTML = "0"+milSec;
    }
    if(milSec>9){
        MSec.innerHTML = milSec;
    }
    if(milSec>99){
        Sec++;
        Seconds.innerHTML = "0"+ Sec;
        milSec = 0;
        MSec.innerHTML = "0"+ 0;
    }
    if(Sec>9){
        Seconds.innerHTML=Sec;
    }
    if(Sec>99){
        min++
        Minutes.innerHTML= min;
        Seconds.innerHTML = "0"+ 0;
        Minutes.innerHTML="0"+ 0;
    }
}
