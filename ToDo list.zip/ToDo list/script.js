let addTodo = document.getElementById('add');
let todoContainer = document.getElementById('ToDo');
let text = document.getElementById('todo');
let para;
addTodo.addEventListener('click', function () {
    let para = document.createElement('h2');
    para.innerText = todo.value;
    todoContainer.appendChild(para);
    text.value = '';

    para.addEventListener('click', function () {
        para.style.textDecoration = "line-through";
    })

    para.addEventListener('dblclick', function () {
        todoContainer.removeChild(para);
    })
})
function Reset() {
    todoContainer.remove();
    location.reload();
}
