function check(form){
    if (form.username.value == "Login" && form.password.value == "login123"){
        alert("Login successful");
        window.open('https://www.google.com/');
    }
    else{
        alert("invalid Login credentials");   
    }
}